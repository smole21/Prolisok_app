export interface Guest {
  name: string;
  phone: string;
}

export interface ExtraService {
  id: string;
  name: string;
  price: number;
  enabled: boolean;
}

export interface Booking {
  id: string;
  houseId: 1 | 2;
  checkInDate: string;
  nights: number;
  guestCount: 2 | 4;
  childrenCount: number;
  guest: Guest;
  comment: string;
  basePrice: number;
  discount: 0 | 5 | 10 | 15 | 20;
  surcharge: 0 | 50 | 100;
  extraServices: string[];
  totalPrice: number;
  advancePayment: number;
  remainingPayment: number;
  createdAt: string;
}

export interface DayPrice {
  day: string;
  price2Guests: number;
  price4Guests: number;
}

export interface Settings {
  prices: DayPrice[];
  extraServices: ExtraService[];
  autoAdvance: boolean;
}

export const DAYS_OF_WEEK = [
  'Понеділок',
  'Вівторок',
  'Середа',
  'Четвер',
  "П'ятниця",
  'Субота',
  'Неділя',
];

export const DEFAULT_EXTRA_SERVICES: ExtraService[] = [
  { id: 'sauna1', name: 'Сауна 1', price: 500, enabled: true },
  { id: 'sauna2', name: 'Сауна 2', price: 500, enabled: true },
  { id: 'bikes', name: 'Велосипеди', price: 200, enabled: true },
  { id: 'pet', name: 'Кіт / Пес', price: 300, enabled: true },
  { id: 'earlyCheckin', name: 'Раннє заселення', price: 400, enabled: true },
  { id: 'extraGuests', name: 'Додаткові гості', price: 350, enabled: true },
  { id: 'firewood', name: 'Дрова', price: 150, enabled: true },
];

export const DEFAULT_PRICES: DayPrice[] = DAYS_OF_WEEK.map((day, index) => ({
  day,
  price2Guests: index >= 4 ? 2500 : 2000,
  price4Guests: index >= 4 ? 3500 : 3000,
}));

export const DEFAULT_SETTINGS: Settings = {
  prices: DEFAULT_PRICES,
  extraServices: DEFAULT_EXTRA_SERVICES,
  autoAdvance: true,
};
