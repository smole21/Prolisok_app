import { useLocalStorage } from './useLocalStorage';
import { Booking, Settings, DEFAULT_SETTINGS } from '@/types/booking';

export function useBookings() {
  const [bookings, setBookings] = useLocalStorage<Booking[]>('bookings', []);
  const [settings, setSettings] = useLocalStorage<Settings>('settings', DEFAULT_SETTINGS);

  const addBooking = (booking: Omit<Booking, 'id' | 'createdAt'>) => {
    const newBooking: Booking = {
      ...booking,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    };
    setBookings(prev => [...prev, newBooking]);
    return newBooking;
  };

  const updateBooking = (id: string, updates: Partial<Booking>) => {
    setBookings(prev =>
      prev.map(b => (b.id === id ? { ...b, ...updates } : b))
    );
  };

  const deleteBooking = (id: string) => {
    setBookings(prev => prev.filter(b => b.id !== id));
  };

  const getBookingsForDate = (date: string, houseId?: 1 | 2) => {
    return bookings.filter(b => {
      const checkIn = new Date(b.checkInDate);
      const checkOut = new Date(checkIn);
      checkOut.setDate(checkOut.getDate() + b.nights);

      const targetDate = new Date(date);
      const isInRange = targetDate >= checkIn && targetDate < checkOut;

      if (houseId) {
        return isInRange && b.houseId === houseId;
      }
      return isInRange;
    });
  };

  const hasConflict = (
    houseId: 1 | 2,
    checkInDate: string,
    nights: number,
    excludeId?: string
  ): boolean => {
    const newCheckIn = new Date(checkInDate);
    const newCheckOut = new Date(newCheckIn);
    newCheckOut.setDate(newCheckOut.getDate() + nights);

    return bookings.some(b => {
      if (b.houseId !== houseId) return false;
      if (excludeId && b.id === excludeId) return false;

      const existingCheckIn = new Date(b.checkInDate);
      const existingCheckOut = new Date(existingCheckIn);
      existingCheckOut.setDate(existingCheckOut.getDate() + b.nights);

      return newCheckIn < existingCheckOut && newCheckOut > existingCheckIn;
    });
  };

  const restoreFromBackup = (newBookings: Booking[], newSettings: Settings) => {
    setBookings(newBookings);
    setSettings(newSettings);
  };

  return {
    bookings,
    settings,
    setSettings,
    addBooking,
    updateBooking,
    deleteBooking,
    getBookingsForDate,
    hasConflict,
    restoreFromBackup,
  };
}
