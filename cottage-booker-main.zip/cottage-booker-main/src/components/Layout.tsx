import { ReactNode } from 'react';
import { NavLink } from 'react-router-dom';
import { Calendar, Plus, List, BarChart3, Settings, Home } from 'lucide-react';
import { cn } from '@/lib/utils';

interface LayoutProps {
  children: ReactNode;
}

const navItems = [
  { to: '/', icon: Calendar, label: 'Календар' },
  { to: '/new-booking', icon: Plus, label: 'Нове бронювання' },
  { to: '/bookings', icon: List, label: 'Бронювання' },
  { to: '/finances', icon: BarChart3, label: 'Фінанси' },
  { to: '/settings', icon: Settings, label: 'Налаштування' },
];

export function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="glass sticky top-0 z-50 border-b border-border/50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg gradient-primary flex items-center justify-center">
              <Home className="w-5 h-5 text-primary-foreground" />
            </div>
            <h1 className="text-xl font-bold text-gradient">Бронювання</h1>
          </div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-medium house-1-bg/20 text-house-1 border border-house-1/30">
              Будинок 1
            </span>
            <span className="px-3 py-1 rounded-full text-xs font-medium house-2-bg/20 text-house-2 border border-house-2/30">
              Будинок 2
            </span>
          </div>
        </div>
      </header>

      <main className="flex-1 container py-6 animate-fade-in">
        {children}
      </main>

      <nav className="glass sticky bottom-0 border-t border-border/50 safe-area-bottom">
        <div className="container">
          <div className="flex items-center justify-around h-16">
            {navItems.map(({ to, icon: Icon, label }) => (
              <NavLink
                key={to}
                to={to}
                className={({ isActive }) =>
                  cn(
                    'flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-all',
                    isActive
                      ? 'text-primary bg-primary/10'
                      : 'text-muted-foreground hover:text-foreground'
                  )
                }
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs font-medium">{label}</span>
              </NavLink>
            ))}
          </div>
        </div>
      </nav>
    </div>
  );
}
