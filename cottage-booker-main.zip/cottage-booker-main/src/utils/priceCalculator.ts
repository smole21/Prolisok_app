import { Settings, DAYS_OF_WEEK } from '@/types/booking';

export function calculatePrice(
  settings: Settings,
  checkInDate: string,
  nights: number,
  guestCount: 2 | 4,
  discount: 0 | 5 | 10 | 15 | 20,
  surcharge: 0 | 50 | 100,
  extraServiceIds: string[]
): { basePrice: number; totalPrice: number; advancePayment: number; remainingPayment: number } {
  let basePrice = 0;
  const startDate = new Date(checkInDate);

  for (let i = 0; i < nights; i++) {
    const currentDate = new Date(startDate);
    currentDate.setDate(currentDate.getDate() + i);
    const dayOfWeek = currentDate.getDay();
    const dayIndex = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
    
    const dayPrice = settings.prices[dayIndex];
    const price = guestCount === 2 ? dayPrice.price2Guests : dayPrice.price4Guests;
    basePrice += price;
  }

  const extraServicesTotal = extraServiceIds.reduce((sum, serviceId) => {
    const service = settings.extraServices.find(s => s.id === serviceId);
    return sum + (service?.price || 0);
  }, 0);

  let totalPrice = basePrice + extraServicesTotal;

  if (surcharge > 0) {
    totalPrice = totalPrice * (1 + surcharge / 100);
  }

  if (discount > 0) {
    totalPrice = totalPrice * (1 - discount / 100);
  }

  totalPrice = Math.round(totalPrice);
  const advancePayment = Math.round(totalPrice * 0.5);
  const remainingPayment = totalPrice - advancePayment;

  return { basePrice, totalPrice, advancePayment, remainingPayment };
}

export function getDayName(date: Date): string {
  const dayIndex = date.getDay();
  return DAYS_OF_WEEK[dayIndex === 0 ? 6 : dayIndex - 1];
}
