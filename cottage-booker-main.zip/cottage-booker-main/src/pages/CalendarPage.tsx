import { useState, useMemo } from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isToday, addMonths, subMonths } from 'date-fns';
import { uk } from 'date-fns/locale';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useBookings } from '@/hooks/useBookings';
import { cn } from '@/lib/utils';
import { Booking } from '@/types/booking';

export default function CalendarPage() {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const { bookings, getBookingsForDate } = useBookings();

  const days = useMemo(() => {
    const start = startOfMonth(currentMonth);
    const end = endOfMonth(currentMonth);
    return eachDayOfInterval({ start, end });
  }, [currentMonth]);

  const firstDayOfMonth = startOfMonth(currentMonth).getDay();
  const emptyDays = firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1;

  const getBookingForDay = (date: Date): { house1?: Booking; house2?: Booking } => {
    const dateStr = format(date, 'yyyy-MM-dd');
    const dayBookings = getBookingsForDate(dateStr);
    return {
      house1: dayBookings.find(b => b.houseId === 1),
      house2: dayBookings.find(b => b.houseId === 2),
    };
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Календар бронювань</h2>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <span className="text-lg font-semibold min-w-[180px] text-center capitalize">
            {format(currentMonth, 'LLLL yyyy', { locale: uk })}
          </span>
          <Button
            variant="outline"
            size="icon"
            onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="glass rounded-xl p-4">
        <div className="grid grid-cols-7 gap-1 mb-2">
          {['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Нд'].map(day => (
            <div key={day} className="text-center text-sm font-medium text-muted-foreground py-2">
              {day}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-1">
          {Array.from({ length: emptyDays }).map((_, i) => (
            <div key={`empty-${i}`} className="aspect-square" />
          ))}
          
          {days.map(day => {
            const { house1, house2 } = getBookingForDay(day);
            const hasBooking = house1 || house2;
            
            return (
              <div
                key={day.toISOString()}
                className={cn(
                  'aspect-square rounded-lg p-1 flex flex-col items-center justify-start gap-1 transition-colors',
                  isToday(day) && 'ring-2 ring-primary',
                  !isSameMonth(day, currentMonth) && 'opacity-50'
                )}
              >
                <span className={cn(
                  'text-sm font-medium w-7 h-7 flex items-center justify-center rounded-full',
                  isToday(day) && 'bg-primary text-primary-foreground'
                )}>
                  {format(day, 'd')}
                </span>
                <div className="flex gap-0.5 w-full justify-center">
                  {house1 && (
                    <div 
                      className="w-2.5 h-2.5 rounded-full house-1-bg" 
                      title={`Будинок 1: ${house1.guest.name}`}
                    />
                  )}
                  {house2 && (
                    <div 
                      className="w-2.5 h-2.5 rounded-full house-2-bg" 
                      title={`Будинок 2: ${house2.guest.name}`}
                    />
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="glass rounded-xl p-4">
        <h3 className="font-semibold mb-3">Активні бронювання</h3>
        {bookings.length === 0 ? (
          <p className="text-muted-foreground text-sm">Немає бронювань</p>
        ) : (
          <div className="space-y-2">
            {bookings.slice(0, 5).map(booking => (
              <div
                key={booking.id}
                className={cn(
                  'flex items-center justify-between p-3 rounded-lg border',
                  booking.houseId === 1 ? 'border-house-1/30 bg-house-1/5' : 'border-house-2/30 bg-house-2/5'
                )}
              >
                <div className="flex items-center gap-3">
                  <div className={cn(
                    'w-3 h-3 rounded-full',
                    booking.houseId === 1 ? 'house-1-bg' : 'house-2-bg'
                  )} />
                  <div>
                    <p className="font-medium">{booking.guest.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {format(new Date(booking.checkInDate), 'd MMM', { locale: uk })} — {booking.nights} ночей
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-primary">{booking.totalPrice} ₴</p>
                  <p className="text-xs text-muted-foreground">Будинок {booking.houseId}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
