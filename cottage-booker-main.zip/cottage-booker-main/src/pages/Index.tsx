import CalendarPage from './CalendarPage';

const Index = () => {
  return <CalendarPage />;
};

export default Index;
