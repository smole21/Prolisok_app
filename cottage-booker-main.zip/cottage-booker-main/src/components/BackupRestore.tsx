import { useRef } from 'react';
import { Download, Upload, Cloud } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { Booking, Settings } from '@/types/booking';

interface BackupRestoreProps {
  bookings: Booking[];
  settings: Settings;
  onRestore: (bookings: Booking[], settings: Settings) => void;
}

interface BackupData {
  version: number;
  exportedAt: string;
  bookings: Booking[];
  settings: Settings;
}

export function BackupRestore({ bookings, settings, onRestore }: BackupRestoreProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleExport = () => {
    const data: BackupData = {
      version: 1,
      exportedAt: new Date().toISOString(),
      bookings,
      settings,
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `booking-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast.success('Резервну копію завантажено');
  };

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const data: BackupData = JSON.parse(content);
        
        if (!data.bookings || !data.settings) {
          throw new Error('Invalid backup format');
        }

        onRestore(data.bookings, data.settings);
        toast.success(`Відновлено ${data.bookings.length} бронювань`);
      } catch (error) {
        console.error('Error importing backup:', error);
        toast.error('Помилка імпорту. Перевірте формат файлу.');
      }
    };
    reader.readAsText(file);
    
    // Reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="glass rounded-xl p-4 space-y-4">
      <div className="flex items-center gap-2">
        <Cloud className="w-5 h-5 text-primary" />
        <h3 className="font-semibold">Резервне копіювання</h3>
      </div>
      
      <p className="text-sm text-muted-foreground">
        Експортуйте дані в JSON-файл і збережіть на Google Drive або іншому хмарному сховищі.
      </p>

      <div className="flex gap-3">
        <Button onClick={handleExport} variant="outline" className="flex-1">
          <Download className="w-4 h-4 mr-2" />
          Експортувати
        </Button>
        
        <Button 
          onClick={() => fileInputRef.current?.click()} 
          variant="outline" 
          className="flex-1"
        >
          <Upload className="w-4 h-4 mr-2" />
          Імпортувати
        </Button>
        
        <input
          ref={fileInputRef}
          type="file"
          accept=".json"
          onChange={handleImport}
          className="hidden"
        />
      </div>
    </div>
  );
}
