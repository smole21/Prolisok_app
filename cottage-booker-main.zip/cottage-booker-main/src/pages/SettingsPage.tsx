import { useState } from 'react';
import { Save, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { useBookings } from '@/hooks/useBookings';
import { toast } from 'sonner';
import { DAYS_OF_WEEK, Settings, DayPrice, ExtraService } from '@/types/booking';
import { BackupRestore } from '@/components/BackupRestore';
import { supabase } from '@/integrations/supabase/client';
export default function SettingsPage() {
  const { settings, setSettings, bookings, restoreFromBackup } = useBookings();
  const [localSettings, setLocalSettings] = useState<Settings>(settings);
  const [isSyncing, setIsSyncing] = useState(false);

  const handleSyncGoogleSheets = async () => {
    setIsSyncing(true);
    try {
      const { data, error } = await supabase.functions.invoke('sync-google-sheets', {
        body: { bookings, settings: localSettings }
      });
      
      if (error) throw error;
      
      if (data.success) {
        toast.success(`Синхронізовано ${bookings.length} бронювань з Google Sheets`);
      } else {
        throw new Error(data.error || 'Помилка синхронізації');
      }
    } catch (error) {
      console.error('Sync error:', error);
      toast.error('Помилка синхронізації з Google Sheets');
    } finally {
      setIsSyncing(false);
    }
  };
  const handlePriceChange = (dayIndex: number, field: 'price2Guests' | 'price4Guests', value: string) => {
    const newPrices = [...localSettings.prices];
    newPrices[dayIndex] = {
      ...newPrices[dayIndex],
      [field]: Number(value) || 0,
    };
    setLocalSettings({ ...localSettings, prices: newPrices });
  };

  const handleServiceChange = (serviceId: string, field: 'price' | 'enabled', value: number | boolean) => {
    const newServices = localSettings.extraServices.map(s =>
      s.id === serviceId ? { ...s, [field]: value } : s
    );
    setLocalSettings({ ...localSettings, extraServices: newServices });
  };

  const handleSave = () => {
    setSettings(localSettings);
    toast.success('Налаштування збережено');
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Налаштування</h2>
        <Button onClick={handleSave} className="gradient-primary text-primary-foreground">
          <Save className="w-4 h-4 mr-2" />
          Зберегти
        </Button>
      </div>

      {/* Google Sheets Sync */}
      <div className="glass rounded-xl p-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-semibold">Google Sheets</h3>
            <p className="text-sm text-muted-foreground">Синхронізувати бронювання з Google таблицею</p>
          </div>
          <Button 
            onClick={handleSyncGoogleSheets} 
            disabled={isSyncing}
            variant="outline"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isSyncing ? 'animate-spin' : ''}`} />
            {isSyncing ? 'Синхронізація...' : 'Синхронізувати'}
          </Button>
        </div>
      </div>

      {/* Backup/Restore */}
      <BackupRestore 
        bookings={bookings} 
        settings={localSettings} 
        onRestore={restoreFromBackup}
      />

      {/* Prices */}
      <div className="glass rounded-xl p-4 space-y-4">
        <h3 className="font-semibold">Ціни оренди (за ніч)</h3>
        
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-4 text-sm font-medium text-muted-foreground">
            <span>День</span>
            <span className="text-center">2 гостя</span>
            <span className="text-center">4 гостя</span>
          </div>
          
          {localSettings.prices.map((dayPrice, index) => (
            <div key={dayPrice.day} className="grid grid-cols-3 gap-4 items-center">
              <span className="font-medium text-sm">{dayPrice.day}</span>
              <Input
                type="number"
                value={dayPrice.price2Guests}
                onChange={e => handlePriceChange(index, 'price2Guests', e.target.value)}
                className="text-center"
              />
              <Input
                type="number"
                value={dayPrice.price4Guests}
                onChange={e => handlePriceChange(index, 'price4Guests', e.target.value)}
                className="text-center"
              />
            </div>
          ))}
        </div>
      </div>

      {/* Extra Services */}
      <div className="glass rounded-xl p-4 space-y-4">
        <h3 className="font-semibold">Додаткові послуги</h3>
        
        <div className="space-y-3">
          {localSettings.extraServices.map(service => (
            <div key={service.id} className="flex items-center gap-4 p-3 bg-secondary/50 rounded-lg">
              <Switch
                checked={service.enabled}
                onCheckedChange={checked => handleServiceChange(service.id, 'enabled', checked)}
              />
              <span className="flex-1 font-medium">{service.name}</span>
              <div className="flex items-center gap-2">
                <Input
                  type="number"
                  value={service.price}
                  onChange={e => handleServiceChange(service.id, 'price', Number(e.target.value))}
                  className="w-24 text-center"
                />
                <span className="text-muted-foreground">₴</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Auto Advance */}
      <div className="glass rounded-xl p-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-semibold">Автоматичний аванс</h3>
            <p className="text-sm text-muted-foreground">Автоматично встановлювати аванс 50%</p>
          </div>
          <Switch
            checked={localSettings.autoAdvance}
            onCheckedChange={checked => setLocalSettings({ ...localSettings, autoAdvance: checked })}
          />
        </div>
      </div>
    </div>
  );
}
