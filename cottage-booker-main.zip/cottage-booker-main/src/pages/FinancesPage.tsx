import { useState, useMemo } from 'react';
import { format, startOfMonth, endOfMonth, isWithinInterval, parseISO } from 'date-fns';
import { uk } from 'date-fns/locale';
import { CalendarIcon, TrendingUp, Wallet, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useBookings } from '@/hooks/useBookings';
import { cn } from '@/lib/utils';

export default function FinancesPage() {
  const { bookings } = useBookings();
  const [dateRange, setDateRange] = useState<{ from: Date; to: Date }>({
    from: startOfMonth(new Date()),
    to: endOfMonth(new Date()),
  });

  const filteredBookings = useMemo(() => {
    return bookings.filter(booking => {
      const checkInDate = parseISO(booking.checkInDate);
      return isWithinInterval(checkInDate, { start: dateRange.from, end: dateRange.to });
    });
  }, [bookings, dateRange]);

  const stats = useMemo(() => {
    const total = filteredBookings.reduce((sum, b) => sum + b.totalPrice, 0);
    const advances = filteredBookings.reduce((sum, b) => sum + b.advancePayment, 0);
    const remaining = filteredBookings.reduce((sum, b) => sum + b.remainingPayment, 0);
    const house1 = filteredBookings.filter(b => b.houseId === 1).reduce((sum, b) => sum + b.totalPrice, 0);
    const house2 = filteredBookings.filter(b => b.houseId === 2).reduce((sum, b) => sum + b.totalPrice, 0);

    return { total, advances, remaining, house1, house2, count: filteredBookings.length };
  }, [filteredBookings]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <h2 className="text-2xl font-bold">Фінанси</h2>
        
        <div className="flex items-center gap-2">
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="justify-start">
                <CalendarIcon className="mr-2 h-4 w-4" />
                {format(dateRange.from, 'd MMM', { locale: uk })} - {format(dateRange.to, 'd MMM yyyy', { locale: uk })}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <Calendar
                mode="range"
                selected={{ from: dateRange.from, to: dateRange.to }}
                onSelect={(range) => {
                  if (range?.from && range?.to) {
                    setDateRange({ from: range.from, to: range.to });
                  }
                }}
                locale={uk}
                numberOfMonths={2}
              />
            </PopoverContent>
          </Popover>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg gradient-primary flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Загальний дохід</p>
              <p className="text-2xl font-bold text-primary">{stats.total.toLocaleString()} ₴</p>
            </div>
          </div>
        </div>

        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-success/20 flex items-center justify-center">
              <Wallet className="w-5 h-5 text-success" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Отримано авансів</p>
              <p className="text-2xl font-bold text-success">{stats.advances.toLocaleString()} ₴</p>
            </div>
          </div>
        </div>

        <div className="glass rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-accent" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Очікується</p>
              <p className="text-2xl font-bold text-accent">{stats.remaining.toLocaleString()} ₴</p>
            </div>
          </div>
        </div>
      </div>

      {/* House breakdown */}
      <div className="glass rounded-xl p-4">
        <h3 className="font-semibold mb-4">Дохід по будинках</h3>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between mb-2">
              <span className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full house-1-bg" />
                Будинок 1
              </span>
              <span className="font-semibold">{stats.house1.toLocaleString()} ₴</span>
            </div>
            <div className="h-2 bg-secondary rounded-full overflow-hidden">
              <div
                className="h-full house-1-bg transition-all"
                style={{ width: stats.total > 0 ? `${(stats.house1 / stats.total) * 100}%` : '0%' }}
              />
            </div>
          </div>
          <div>
            <div className="flex justify-between mb-2">
              <span className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full house-2-bg" />
                Будинок 2
              </span>
              <span className="font-semibold">{stats.house2.toLocaleString()} ₴</span>
            </div>
            <div className="h-2 bg-secondary rounded-full overflow-hidden">
              <div
                className="h-full house-2-bg transition-all"
                style={{ width: stats.total > 0 ? `${(stats.house2 / stats.total) * 100}%` : '0%' }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Bookings List */}
      <div className="glass rounded-xl p-4">
        <h3 className="font-semibold mb-4">Бронювання за період ({stats.count})</h3>
        
        {filteredBookings.length === 0 ? (
          <p className="text-muted-foreground text-sm text-center py-4">Немає бронювань за цей період</p>
        ) : (
          <div className="space-y-2">
            {filteredBookings.map(booking => (
              <div
                key={booking.id}
                className={cn(
                  'flex items-center justify-between p-3 rounded-lg border',
                  booking.houseId === 1 ? 'border-house-1/30 bg-house-1/5' : 'border-house-2/30 bg-house-2/5'
                )}
              >
                <div className="flex items-center gap-3">
                  <div className={cn(
                    'w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold',
                    booking.houseId === 1 ? 'bg-house-1/20 text-house-1' : 'bg-house-2/20 text-house-2'
                  )}>
                    {booking.houseId}
                  </div>
                  <div>
                    <p className="font-medium">{booking.guest.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {format(parseISO(booking.checkInDate), 'd MMM', { locale: uk })} — {booking.nights} ночей
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-primary">{booking.totalPrice.toLocaleString()} ₴</p>
                  <p className="text-xs text-muted-foreground">
                    Аванс: {booking.advancePayment.toLocaleString()} ₴
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
