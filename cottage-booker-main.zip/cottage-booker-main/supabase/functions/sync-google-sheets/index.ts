import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Get JWT token for Google API
async function getAccessToken(): Promise<string> {
  const email = Deno.env.get('GOOGLE_SERVICE_ACCOUNT_EMAIL');
  const privateKey = Deno.env.get('GOOGLE_PRIVATE_KEY');
  
  if (!email || !privateKey) {
    throw new Error('Missing Google credentials');
  }

  const now = Math.floor(Date.now() / 1000);
  const exp = now + 3600;

  const header = { alg: 'RS256', typ: 'JWT' };
  const payload = {
    iss: email,
    scope: 'https://www.googleapis.com/auth/spreadsheets',
    aud: 'https://oauth2.googleapis.com/token',
    iat: now,
    exp: exp,
  };

  const encoder = new TextEncoder();
  const headerB64 = btoa(JSON.stringify(header)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const payloadB64 = btoa(JSON.stringify(payload)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
  const signatureInput = `${headerB64}.${payloadB64}`;

  // Import private key
  const pemContents = privateKey
    .replace('-----BEGIN PRIVATE KEY-----', '')
    .replace('-----END PRIVATE KEY-----', '')
    .replace(/\n/g, '');
  
  const binaryKey = Uint8Array.from(atob(pemContents), c => c.charCodeAt(0));
  
  const cryptoKey = await crypto.subtle.importKey(
    'pkcs8',
    binaryKey,
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['sign']
  );

  const signature = await crypto.subtle.sign(
    'RSASSA-PKCS1-v1_5',
    cryptoKey,
    encoder.encode(signatureInput)
  );

  const signatureB64 = btoa(String.fromCharCode(...new Uint8Array(signature)))
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');

  const jwt = `${signatureInput}.${signatureB64}`;

  // Exchange JWT for access token
  const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`,
  });

  const tokenData = await tokenResponse.json();
  
  if (!tokenData.access_token) {
    console.error('Token response:', tokenData);
    throw new Error('Failed to get access token');
  }

  return tokenData.access_token;
}

// Format booking data for Google Sheets
function formatBookingsForSheets(bookings: any[]) {
  const headers = [
    'ID', 'Будинок', 'Гість', 'Телефон', 'Дата заїзду', 'Ночей', 
    'Гостей', 'Сума', 'Депозит', 'Статус оплати', 'Примітки', 'Створено'
  ];

  const rows = bookings.map(b => [
    b.id,
    b.houseId === 1 ? 'Будинок 1' : 'Будинок 2',
    b.guestName,
    b.phone || '',
    b.checkInDate,
    b.nights,
    b.guests,
    b.totalPrice,
    b.deposit || 0,
    b.paymentStatus || 'pending',
    b.notes || '',
    b.createdAt
  ]);

  return [headers, ...rows];
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { bookings, settings } = await req.json();
    const spreadsheetId = Deno.env.get('GOOGLE_SPREADSHEET_ID');

    if (!spreadsheetId) {
      throw new Error('Missing GOOGLE_SPREADSHEET_ID');
    }

    console.log(`Syncing ${bookings?.length || 0} bookings to Google Sheets...`);

    const accessToken = await getAccessToken();

    // Clear and update Bookings sheet
    const bookingsData = formatBookingsForSheets(bookings || []);
    
    // First, clear the existing data
    await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Bookings!A:L:clear`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
      }
    );

    // Then write new data
    const updateResponse = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/Bookings!A1?valueInputOption=RAW`,
      {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          range: 'Bookings!A1',
          majorDimension: 'ROWS',
          values: bookingsData,
        }),
      }
    );

    const updateResult = await updateResponse.json();
    
    if (updateResult.error) {
      console.error('Google Sheets API error:', updateResult.error);
      throw new Error(updateResult.error.message);
    }

    console.log('Sync completed successfully:', updateResult);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Synced ${bookings?.length || 0} bookings`,
        updatedCells: updateResult.updatedCells 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Sync error:', error);
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
