import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { uk } from 'date-fns/locale';
import { CalendarIcon, User, Phone, MessageSquare, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { useBookings } from '@/hooks/useBookings';
import { calculatePrice } from '@/utils/priceCalculator';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export default function NewBookingPage() {
  const navigate = useNavigate();
  const { settings, addBooking, hasConflict } = useBookings();
  
  const [houseId, setHouseId] = useState<1 | 2>(1);
  const [checkInDate, setCheckInDate] = useState<Date>();
  const [nights, setNights] = useState(1);
  const [guestCount, setGuestCount] = useState<2 | 4>(2);
  const [childrenCount, setChildrenCount] = useState(0);
  const [guestName, setGuestName] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [comment, setComment] = useState('');
  const [discount, setDiscount] = useState<0 | 5 | 10 | 15 | 20>(0);
  const [surcharge, setSurcharge] = useState<0 | 50 | 100>(0);
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [advancePayment, setAdvancePayment] = useState(0);
  const [conflict, setConflict] = useState(false);

  const priceData = checkInDate
    ? calculatePrice(settings, format(checkInDate, 'yyyy-MM-dd'), nights, guestCount, discount, surcharge, selectedServices)
    : null;

  useEffect(() => {
    if (priceData && settings.autoAdvance) {
      setAdvancePayment(priceData.advancePayment);
    }
  }, [priceData, settings.autoAdvance]);

  useEffect(() => {
    if (checkInDate) {
      setConflict(hasConflict(houseId, format(checkInDate, 'yyyy-MM-dd'), nights));
    }
  }, [houseId, checkInDate, nights, hasConflict]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!checkInDate || !guestName || !guestPhone) {
      toast.error('Заповніть обов\'язкові поля');
      return;
    }

    if (conflict) {
      toast.error('На ці дати вже є бронювання');
      return;
    }

    const remainingPayment = (priceData?.totalPrice || 0) - advancePayment;

    addBooking({
      houseId,
      checkInDate: format(checkInDate, 'yyyy-MM-dd'),
      nights,
      guestCount,
      childrenCount,
      guest: { name: guestName, phone: guestPhone },
      comment,
      basePrice: priceData?.basePrice || 0,
      discount,
      surcharge,
      extraServices: selectedServices,
      totalPrice: priceData?.totalPrice || 0,
      advancePayment,
      remainingPayment,
    });

    toast.success('Бронювання створено!');
    navigate('/');
  };

  const toggleService = (serviceId: string) => {
    setSelectedServices(prev =>
      prev.includes(serviceId)
        ? prev.filter(id => id !== serviceId)
        : [...prev, serviceId]
    );
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold">Нове бронювання</h2>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* House Selection */}
        <div className="glass rounded-xl p-4 space-y-4">
          <h3 className="font-semibold">Вибір будинку</h3>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setHouseId(1)}
              className={cn(
                'p-4 rounded-lg border-2 transition-all',
                houseId === 1
                  ? 'border-house-1 bg-house-1/10'
                  : 'border-border hover:border-house-1/50'
              )}
            >
              <div className="w-4 h-4 rounded-full house-1-bg mx-auto mb-2" />
              <span className="font-medium">Будинок 1</span>
            </button>
            <button
              type="button"
              onClick={() => setHouseId(2)}
              className={cn(
                'p-4 rounded-lg border-2 transition-all',
                houseId === 2
                  ? 'border-house-2 bg-house-2/10'
                  : 'border-border hover:border-house-2/50'
              )}
            >
              <div className="w-4 h-4 rounded-full house-2-bg mx-auto mb-2" />
              <span className="font-medium">Будинок 2</span>
            </button>
          </div>
        </div>

        {/* Dates */}
        <div className="glass rounded-xl p-4 space-y-4">
          <h3 className="font-semibold">Дати проживання</h3>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Дата заїзду</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {checkInDate ? format(checkInDate, 'PPP', { locale: uk }) : 'Оберіть дату'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={checkInDate}
                    onSelect={setCheckInDate}
                    locale={uk}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label>Кількість ночей</Label>
              <Select value={String(nights)} onValueChange={v => setNights(Number(v))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 14 }, (_, i) => i + 1).map(n => (
                    <SelectItem key={n} value={String(n)}>{n} {n === 1 ? 'ніч' : n < 5 ? 'ночі' : 'ночей'}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {conflict && (
            <div className="flex items-center gap-2 text-destructive bg-destructive/10 p-3 rounded-lg">
              <AlertCircle className="w-4 h-4" />
              <span className="text-sm">На ці дати вже є бронювання</span>
            </div>
          )}
        </div>

        {/* Guests */}
        <div className="glass rounded-xl p-4 space-y-4">
          <h3 className="font-semibold">Гості</h3>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Кількість гостей</Label>
              <Select value={String(guestCount)} onValueChange={v => setGuestCount(Number(v) as 2 | 4)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2">2 гостя</SelectItem>
                  <SelectItem value="4">4 гостя</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Кількість дітей</Label>
              <Select value={String(childrenCount)} onValueChange={v => setChildrenCount(Number(v))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: 6 }, (_, i) => i).map(n => (
                    <SelectItem key={n} value={String(n)}>{n}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <User className="w-4 h-4" />
                Ім'я
              </Label>
              <Input
                value={guestName}
                onChange={e => setGuestName(e.target.value)}
                placeholder="Введіть ім'я"
                required
              />
            </div>

            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Phone className="w-4 h-4" />
                Телефон
              </Label>
              <Input
                value={guestPhone}
                onChange={e => setGuestPhone(e.target.value)}
                placeholder="+380..."
                required
              />
            </div>
          </div>
        </div>

        {/* Pricing */}
        <div className="glass rounded-xl p-4 space-y-4">
          <h3 className="font-semibold">Ціноутворення</h3>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Знижка</Label>
              <Select value={String(discount)} onValueChange={v => setDiscount(Number(v) as 0 | 5 | 10 | 15 | 20)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">Без знижки</SelectItem>
                  <SelectItem value="5">5%</SelectItem>
                  <SelectItem value="10">10%</SelectItem>
                  <SelectItem value="15">15%</SelectItem>
                  <SelectItem value="20">20%</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Святкова націнка</Label>
              <Select value={String(surcharge)} onValueChange={v => setSurcharge(Number(v) as 0 | 50 | 100)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0">Без націнки</SelectItem>
                  <SelectItem value="50">+50%</SelectItem>
                  <SelectItem value="100">+100%</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Extra Services */}
        <div className="glass rounded-xl p-4 space-y-4">
          <h3 className="font-semibold">Додаткові послуги</h3>
          <div className="grid grid-cols-2 gap-3">
            {settings.extraServices.filter(s => s.enabled).map(service => (
              <label
                key={service.id}
                className={cn(
                  'flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors',
                  selectedServices.includes(service.id)
                    ? 'border-primary bg-primary/10'
                    : 'border-border hover:border-primary/50'
                )}
              >
                <Checkbox
                  checked={selectedServices.includes(service.id)}
                  onCheckedChange={() => toggleService(service.id)}
                />
                <div className="flex-1">
                  <p className="font-medium text-sm">{service.name}</p>
                  <p className="text-xs text-muted-foreground">{service.price} ₴</p>
                </div>
              </label>
            ))}
          </div>
        </div>

        {/* Comment */}
        <div className="glass rounded-xl p-4 space-y-4">
          <Label className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4" />
            Коментар
          </Label>
          <Textarea
            value={comment}
            onChange={e => setComment(e.target.value)}
            placeholder="Додаткова інформація..."
            rows={3}
          />
        </div>

        {/* Price Summary */}
        {priceData && (
          <div className="glass rounded-xl p-4 space-y-3">
            <h3 className="font-semibold">Розрахунок вартості</h3>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Базова ціна</span>
                <span>{priceData.basePrice} ₴</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-sm text-success">
                  <span>Знижка {discount}%</span>
                  <span>-{Math.round(priceData.basePrice * discount / 100)} ₴</span>
                </div>
              )}
              {surcharge > 0 && (
                <div className="flex justify-between text-sm text-destructive">
                  <span>Націнка {surcharge}%</span>
                  <span>+{Math.round(priceData.basePrice * surcharge / 100)} ₴</span>
                </div>
              )}
              <div className="border-t border-border pt-2 flex justify-between font-semibold text-lg">
                <span>Всього</span>
                <span className="text-primary">{priceData.totalPrice} ₴</span>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Аванс (50%)</Label>
              <Input
                type="number"
                value={advancePayment}
                onChange={e => setAdvancePayment(Number(e.target.value))}
              />
              <p className="text-sm text-muted-foreground">
                Залишок до оплати: <strong>{priceData.totalPrice - advancePayment} ₴</strong>
              </p>
            </div>
          </div>
        )}

        <Button type="submit" className="w-full gradient-primary text-primary-foreground h-12 text-lg font-semibold" disabled={conflict}>
          Створити бронювання
        </Button>
      </form>
    </div>
  );
}
