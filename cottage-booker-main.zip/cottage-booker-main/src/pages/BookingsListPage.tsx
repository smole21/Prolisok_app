import { useState } from 'react';
import { format } from 'date-fns';
import { uk } from 'date-fns/locale';
import { Trash2, Phone, MessageSquare, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useBookings } from '@/hooks/useBookings';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function BookingsListPage() {
  const { bookings, settings, deleteBooking } = useBookings();
  const [filterHouse, setFilterHouse] = useState<'all' | '1' | '2'>('all');

  const filteredBookings = bookings.filter(b => {
    if (filterHouse === 'all') return true;
    return b.houseId === Number(filterHouse);
  }).sort((a, b) => new Date(b.checkInDate).getTime() - new Date(a.checkInDate).getTime());

  const handleDelete = (id: string) => {
    deleteBooking(id);
    toast.success('Бронювання видалено');
  };

  const getServiceNames = (serviceIds: string[]) => {
    return serviceIds.map(id => {
      const service = settings.extraServices.find(s => s.id === id);
      return service?.name || id;
    }).join(', ');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Бронювання</h2>
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <Select value={filterHouse} onValueChange={(v: 'all' | '1' | '2') => setFilterHouse(v)}>
            <SelectTrigger className="w-[140px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Всі будинки</SelectItem>
              <SelectItem value="1">Будинок 1</SelectItem>
              <SelectItem value="2">Будинок 2</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {filteredBookings.length === 0 ? (
        <div className="glass rounded-xl p-8 text-center">
          <p className="text-muted-foreground">Немає бронювань</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredBookings.map(booking => (
            <div
              key={booking.id}
              className={cn(
                'glass rounded-xl p-4 space-y-4 animate-fade-in',
                booking.houseId === 1 ? 'border-l-4 border-l-house-1' : 'border-l-4 border-l-house-2'
              )}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className={cn(
                    'w-10 h-10 rounded-lg flex items-center justify-center font-bold',
                    booking.houseId === 1 ? 'bg-house-1/20 text-house-1' : 'bg-house-2/20 text-house-2'
                  )}>
                    {booking.houseId}
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">{booking.guest.name}</h3>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Phone className="w-3 h-3" />
                      <a href={`tel:${booking.guest.phone}`} className="hover:text-primary">
                        {booking.guest.phone}
                      </a>
                    </div>
                  </div>
                </div>
                
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Видалити бронювання?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Цю дію неможливо скасувати. Бронювання буде видалено назавжди.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Скасувати</AlertDialogCancel>
                      <AlertDialogAction onClick={() => handleDelete(booking.id)}>
                        Видалити
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Заїзд</p>
                  <p className="font-medium">{format(new Date(booking.checkInDate), 'd MMMM yyyy', { locale: uk })}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Тривалість</p>
                  <p className="font-medium">{booking.nights} {booking.nights === 1 ? 'ніч' : booking.nights < 5 ? 'ночі' : 'ночей'}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Гості</p>
                  <p className="font-medium">{booking.guestCount} дорослих, {booking.childrenCount} дітей</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Будинок</p>
                  <p className="font-medium">Будинок {booking.houseId}</p>
                </div>
              </div>

              {booking.extraServices.length > 0 && (
                <div className="text-sm">
                  <p className="text-muted-foreground">Додаткові послуги</p>
                  <p className="font-medium">{getServiceNames(booking.extraServices)}</p>
                </div>
              )}

              {booking.comment && (
                <div className="flex items-start gap-2 text-sm bg-secondary/50 p-3 rounded-lg">
                  <MessageSquare className="w-4 h-4 mt-0.5 text-muted-foreground" />
                  <p>{booking.comment}</p>
                </div>
              )}

              <div className="flex items-center justify-between pt-2 border-t border-border">
                <div className="flex gap-4 text-sm">
                  {booking.discount > 0 && (
                    <span className="text-success">Знижка: {booking.discount}%</span>
                  )}
                  {booking.surcharge > 0 && (
                    <span className="text-destructive">Націнка: {booking.surcharge}%</span>
                  )}
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-primary">{booking.totalPrice} ₴</p>
                  <p className="text-xs text-muted-foreground">
                    Аванс: {booking.advancePayment} ₴ | Залишок: {booking.remainingPayment} ₴
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
